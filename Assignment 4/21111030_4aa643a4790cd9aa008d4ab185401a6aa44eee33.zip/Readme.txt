CSV Description

test_gcm_a1g1.csv - Predicted labels by GCM model when alpha = [0.65,0.35] and gamma = [0.34,0.34,0.32]

test_gcm_a1g2.csv - Predicted labels by GCM model when alpha = [0.65,0.35] and gamma = [0.34,0.49,0.17]

test_gcm_a2g1.csv - Predicted labels by GCM model when alpha = [0.55,0.45] and gamma = [0.34,0.34,0.32]

test_gcm_a2g2.csv - Predicted labels by GCM model when alpha = [0.55,0.45] and gamma = [0.34,0.49,0.17]

test_rmc_a1c1.csv - Predicted labels by RMC model when alpha = [0.21,0.27,0.52] and c = 0.0001

test_rmc_a2c1.csv - Predicted labels by RMC model when alpha = [0.33,0.33,0.34] and c = 0.0001

test_rmc_a1c2.csv - Predicted labels by RMC model when alpha = [0.21,0.27,0.52] and c = 0.1

test_rmc_a2c2.csv - Predicted labels by RMC model when alpha = [0.33,0.33,0.34] and c = 0.1


